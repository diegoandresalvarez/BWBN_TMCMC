#!/usr/bin/python

import matplotlib
matplotlib.rc('text', usetex = True)
import numpy as np
import math
import matplotlib.pyplot as plt

font = {'family' : 'helvetica',
        'size'   : 18}

# matplotlib.rc('font', **font)

t1 = np.genfromtxt('time.txt')
y1 = np.genfromtxt('displ_real.txt')
y2 = np.genfromtxt('displ_est.txt')

plt.plot(t1, y1, 'b', label='Experimental')
plt.plot(t1, y2, 'r--', linewidth=2, label='Estimated')
plt.xlabel('Time (s)')
plt.ylabel('Displacement (mm)')
plt.grid(True)
plt.legend(loc='upper left')
plt.savefig('displacements.eps')